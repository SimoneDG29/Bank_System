
public class BankAccount {
	protected String IBAN;
	protected double Saldo=0.0d;
	private Owner Owner;

	
	public BankAccount(String ib, Owner ow) {
		IBAN=ib;
		Owner=ow;
	}
	
	
	boolean Preleva(double Amount) {
		if(Amount<=Saldo) {
			Saldo=Saldo-Amount;
			System.out.println("Prelievo Effettuato");
			return true;
		}
		else
		{
			System.out.println("Saldo Insufficiente");
			return false;	
		}
		
		
	}
	
	
	public void PrintDetails()
	{
		System.out.print("Il Conto "+IBAN+" ha saldo "+Saldo);
	}
}
